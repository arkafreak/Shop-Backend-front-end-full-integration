-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: shop1
-- ------------------------------------------------------
-- Server version	8.0.40-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Product_images`
--

DROP TABLE IF EXISTS `Product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Product_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `Product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product_images`
--

LOCK TABLES `Product_images` WRITE;
/*!40000 ALTER TABLE `Product_images` DISABLE KEYS */;
INSERT INTO `Product_images` VALUES (1,15,'product1_image1.jpg','2024-11-18 12:02:34'),(2,15,'product1_image2.jpg','2024-11-18 12:02:34'),(3,16,'product2_image1.jpg','2024-11-18 12:02:34'),(4,17,'product3_image1.jpg','2024-11-19 03:26:30'),(6,19,'product5_image1.jpg','2024-11-19 03:26:30'),(7,20,'product6_image1.jpg','2024-11-19 03:26:30'),(8,21,'product7_image1.jpg','2024-11-19 03:26:30'),(9,37,'product8_image1.jpg','2024-11-19 06:21:24'),(10,37,'product8_image2.jpg','2024-11-19 06:21:24'),(11,37,'product8_image3.jpg','2024-11-19 06:21:24'),(12,37,'product8_image4.jpg','2024-11-19 06:21:24'),(13,37,'product8_image5.jpg','2024-11-19 06:21:24'),(14,37,'product8_image6.jpg','2024-11-19 06:21:24'),(15,38,'product9_image1.jpg','2024-11-20 05:48:57'),(16,38,'product9_image2.jpg','2024-11-20 05:48:57'),(17,38,'product9_image3.jpg','2024-11-20 05:48:57'),(19,38,'product9_image5.jpg','2024-11-20 05:48:57'),(20,38,'product9_image6.jpg','2024-11-20 05:48:57'),(21,38,'product9_image7.jpg','2024-11-20 05:48:57'),(22,55,'719LcA76E5L._SX679_.jpg','2024-11-20 08:48:02'),(24,57,'61DjMd76QnL._SX679_.jpg','2024-11-20 08:52:00'),(38,64,'71Bi6UsIoIL._SX679_.jpg','2024-11-20 09:08:15'),(39,64,'51eDyNRz94L._SX679_.jpg','2024-11-20 09:08:15'),(50,75,'51-3rfCGrdL._SY450_.jpg','2024-11-20 10:07:40'),(57,85,'513dZgel4BL._SY450_.jpg','2024-11-21 07:01:31'),(59,88,'51afJC92cgL._SL1000_.jpg','2024-11-21 07:16:51'),(62,93,'51omK_5VIWL._SL1000_.jpg','2024-11-21 07:38:47'),(63,16,'61_E7_iCllL._SX569_.jpg','2024-11-22 03:55:11'),(64,16,'71DUsEo7LtL._SX569_.jpg','2024-11-22 04:03:07'),(65,95,'71oKxmjjZ5L._SY879_.jpg','2024-11-25 04:50:29'),(66,95,'61CAvdVspAL._SY879_.jpg','2024-11-25 04:50:29'),(67,96,'61b6DTHgNWL._SX569_.jpg','2024-11-25 12:28:27'),(69,96,'71ar0zl4x1L._SX569_.jpg','2024-11-25 12:28:27'),(92,18,'71657TiFeHL._SX679_.jpg','2024-11-26 12:05:16'),(95,18,'71d7rfSl0wL._SX679_.jpg','2024-11-27 03:36:02'),(96,18,'712CBkmhLhL._SX679_.jpg','2024-11-27 03:36:02'),(97,18,'81BnjSLm2oL._SX679_.jpg','2024-11-27 03:36:02'),(98,18,'61f4dTush1L._SX679_.jpg','2024-11-27 03:36:02'),(99,18,'51wKeZuX6rL._SX679_.jpg','2024-11-27 03:36:02'),(134,111,'710SxepIfiL._SX569_.jpg','2024-11-29 06:25:04'),(136,111,'6182na8zwFL._SX569_.jpg','2024-12-04 06:47:30'),(137,111,'718scM9ZeIL._SX569_.jpg','2024-12-04 06:47:30'),(140,113,'51ebZJ_DR4L._SY425_.jpg','2024-12-05 07:18:35');
/*!40000 ALTER TABLE `Product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `cartId` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `orderId` int DEFAULT NULL,
  PRIMARY KEY (`cartId`),
  KEY `userId` (`userId`),
  KEY `fk_product` (`productId`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`),
  CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_product` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (60,10,113,1,363),(63,17,55,1,370),(85,2,38,1,396);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (3,'Furniture'),(4,'Games'),(5,'Laptops'),(6,'Mobile Phones'),(11,'Vegetables'),(14,'Fruits'),(15,'Gym Equipments');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int DEFAULT NULL,
  `productId` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orderId` (`orderId`),
  KEY `order_items_ibfk_2` (`productId`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,136,15,7),(2,136,16,1),(3,137,15,1),(4,137,16,4),(5,137,17,2),(6,138,15,1),(7,138,17,1),(8,138,18,1),(9,138,19,1),(10,138,20,1),(11,139,15,2),(12,139,16,12),(13,139,17,13),(14,139,18,3),(15,140,18,1),(16,158,15,1),(17,160,19,1),(18,160,15,1),(19,160,16,1),(20,163,19,1),(21,163,95,1),(22,163,37,1),(23,163,38,1),(24,163,20,1),(25,163,57,1),(26,166,19,1),(27,166,17,1),(28,186,19,1),(29,186,38,1),(30,186,85,1),(31,186,57,1),(32,186,15,1),(33,187,95,1),(34,187,15,1),(35,187,64,2),(36,188,18,1),(37,188,15,1),(38,189,19,1),(39,189,55,1),(40,190,18,1),(41,191,38,1),(42,192,38,1),(43,192,18,1),(44,193,19,1),(45,194,19,6),(46,195,18,1),(47,196,17,1),(48,196,95,1),(49,196,16,1),(50,196,85,1),(51,196,38,1),(52,197,19,1),(53,197,20,1),(54,198,19,3),(55,198,18,1),(56,198,17,1),(57,198,NULL,1),(58,199,NULL,1),(59,200,NULL,1),(60,201,NULL,1),(61,202,NULL,1),(62,203,NULL,1),(67,208,111,5),(68,209,111,5),(69,211,111,5),(70,213,111,5),(72,221,111,5),(73,221,96,1),(74,222,111,5),(75,223,111,5),(76,224,111,5),(77,225,111,5),(78,226,111,5),(79,240,111,5),(80,274,111,5),(81,279,111,5),(82,280,111,1),(83,281,111,1),(84,282,111,1),(85,283,111,1),(86,284,111,1),(87,297,111,1),(88,299,111,1),(89,301,111,1),(90,303,111,1),(91,316,111,5),(92,331,111,5),(93,331,19,1),(94,331,113,1),(95,332,111,1),(96,332,113,1),(97,333,111,1),(98,333,113,1),(99,337,111,3),(100,338,111,3),(101,342,113,1),(102,343,113,1),(103,351,113,1);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `orderStatus` enum('pending','completed','canceled') DEFAULT 'pending',
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `isDiscontinued` tinyint(1) DEFAULT '0',
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL,
  `timerRestarted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,2,75900.00,'completed','2024-11-04 07:36:51','paypal',0,NULL,NULL,0),(2,2,79300.00,'completed','2024-11-04 07:44:43','paypal',0,NULL,NULL,0),(3,2,151900.00,'completed','2024-11-04 07:47:34','paypal',0,NULL,NULL,0),(4,2,152800.00,'completed','2024-11-04 08:03:50','paypal',0,NULL,NULL,0),(5,2,75000.00,'completed','2024-11-04 09:23:13','paypal',0,NULL,NULL,0),(6,2,2000.00,'completed','2024-11-04 09:30:48','paypal',0,NULL,NULL,0),(7,2,81400.00,'completed','2024-11-04 09:37:01','paypal',0,NULL,NULL,0),(8,2,75900.00,'completed','2024-11-04 11:08:33','paypal',0,NULL,NULL,0),(9,2,76900.00,'completed','2024-11-04 11:42:50','paypal',0,NULL,NULL,0),(10,2,525000.00,'completed','2024-11-04 11:49:23','paypal',0,NULL,NULL,0),(11,2,80500.00,'completed','2024-11-04 12:03:20','paypal',0,NULL,NULL,0),(12,2,75900.00,'completed','2024-11-04 12:16:11','paypal',0,NULL,NULL,0),(13,2,156300.00,'completed','2024-11-04 12:23:50','paypal',0,NULL,NULL,0),(14,2,151900.00,'completed','2024-11-05 03:23:13','paypal',0,NULL,NULL,0),(15,2,80400.00,'completed','2024-11-05 03:41:33','paypal',0,NULL,NULL,0),(16,2,2000.00,'completed','2024-11-05 03:43:49','paypal',0,NULL,NULL,0),(17,2,152900.00,'completed','2024-11-05 04:04:42','paypal',0,NULL,NULL,0),(18,10,151900.00,'completed','2024-11-05 04:50:10','paypal',0,NULL,NULL,0),(19,11,601800.00,'completed','2024-11-05 05:28:06','paypal',0,NULL,NULL,0),(20,12,228800.00,'completed','2024-11-05 05:38:33','paypal',0,NULL,NULL,0),(21,12,75900.00,'completed','2024-11-05 05:50:14','paypal',0,NULL,NULL,0),(22,10,231300.00,'completed','2024-11-05 05:55:06','paypal',0,NULL,NULL,0),(23,10,151900.00,'completed','2024-11-05 05:58:44','paypal',0,NULL,NULL,0),(24,10,231300.00,'completed','2024-11-05 06:15:29','paypal',0,NULL,NULL,0),(25,10,375000.00,'completed','2024-11-05 06:39:52','paypal',0,NULL,NULL,0),(26,10,454800.00,'canceled','2024-11-05 10:37:51','paypal',0,NULL,NULL,0),(27,10,454800.00,'canceled','2024-11-05 10:40:19','paypal',0,NULL,NULL,0),(28,10,454800.00,'canceled','2024-11-05 10:40:33','paypal',0,NULL,NULL,0),(29,10,454800.00,'canceled','2024-11-05 10:40:46','paypal',0,NULL,NULL,0),(30,10,454800.00,'canceled','2024-11-05 10:41:00','paypal',0,NULL,NULL,0),(31,10,454800.00,'completed','2024-11-05 10:41:29','paypal',0,NULL,NULL,0),(32,10,76000.00,'canceled','2024-11-05 10:49:30','paypal',0,NULL,NULL,0),(33,10,76000.00,'completed','2024-11-05 10:50:32','paypal',0,NULL,NULL,0),(34,10,75000.00,'completed','2024-11-05 10:53:46','paypal',0,NULL,NULL,0),(35,10,150900.00,'canceled','2024-11-05 11:00:09','paypal',0,NULL,NULL,0),(36,10,150900.00,'canceled','2024-11-05 11:00:58','paypal',0,NULL,NULL,0),(37,10,150900.00,'canceled','2024-11-05 11:07:17','paypal',0,NULL,NULL,0),(38,10,150900.00,'canceled','2024-11-05 11:12:22','paypal',0,NULL,NULL,0),(39,10,150900.00,'completed','2024-11-05 11:12:25','paypal',0,NULL,NULL,0),(40,10,76000.00,'canceled','2024-11-05 11:21:49','paypal',0,NULL,NULL,0),(41,10,76000.00,'completed','2024-11-05 11:24:16','paypal',0,NULL,NULL,0),(42,10,150000.00,'completed','2024-11-05 11:27:57','paypal',0,NULL,NULL,0),(43,10,75900.00,'completed','2024-11-05 11:53:36','paypal',0,NULL,NULL,0),(44,10,75900.00,'completed','2024-11-05 12:11:40','paypal',0,NULL,NULL,0),(45,10,76900.00,'completed','2024-11-06 03:30:09','stripe',0,NULL,NULL,0),(46,10,75900.00,'canceled','2024-11-06 03:34:52','stripe',0,NULL,NULL,0),(47,10,77700.00,'canceled','2024-11-06 03:56:44','stripe',0,NULL,NULL,0),(48,10,77700.00,'canceled','2024-11-06 03:57:08','stripe',0,NULL,NULL,0),(49,10,77700.00,'canceled','2024-11-06 03:57:30','stripe',0,NULL,NULL,0),(50,10,77700.00,'canceled','2024-11-06 03:57:40','stripe',0,NULL,NULL,0),(51,10,77700.00,'canceled','2024-11-06 03:58:57','stripe',0,NULL,NULL,0),(52,10,77700.00,'canceled','2024-11-06 04:00:33','stripe',0,NULL,NULL,0),(53,10,77700.00,'canceled','2024-11-06 04:02:20','stripe',0,NULL,NULL,0),(54,10,77700.00,'canceled','2024-11-06 04:02:39','stripe',0,NULL,NULL,0),(55,10,77700.00,'canceled','2024-11-06 04:11:09','stripe',0,NULL,NULL,0),(56,10,77700.00,'canceled','2024-11-06 04:23:18','stripe',0,NULL,NULL,0),(57,10,77700.00,'canceled','2024-11-06 04:24:09','stripe',0,NULL,NULL,0),(58,10,77700.00,'canceled','2024-11-06 04:25:34','stripe',0,NULL,NULL,0),(59,10,77700.00,'canceled','2024-11-06 04:27:28','stripe',0,NULL,NULL,0),(60,10,77700.00,'canceled','2024-11-06 04:30:27','stripe',0,NULL,NULL,0),(61,10,77700.00,'canceled','2024-11-06 04:32:29','stripe',0,NULL,NULL,0),(62,10,77700.00,'canceled','2024-11-06 04:33:45','stripe',0,NULL,NULL,0),(63,10,77700.00,'canceled','2024-11-06 04:36:11','stripe',0,NULL,NULL,0),(64,10,77700.00,'canceled','2024-11-06 04:41:51','stripe',0,NULL,NULL,0),(65,10,77700.00,'canceled','2024-11-06 04:42:34','stripe',0,NULL,NULL,0),(66,10,77700.00,'canceled','2024-11-06 04:43:38','stripe',0,NULL,NULL,0),(67,10,77700.00,'canceled','2024-11-06 04:44:06','stripe',0,NULL,NULL,0),(68,10,77700.00,'canceled','2024-11-06 04:44:54','stripe',0,NULL,NULL,0),(69,10,77700.00,'canceled','2024-11-06 04:45:10','stripe',0,NULL,NULL,0),(70,10,77700.00,'canceled','2024-11-06 04:45:15','stripe',0,NULL,NULL,0),(71,10,77700.00,'canceled','2024-11-06 04:54:11','stripe',0,NULL,NULL,0),(72,10,77700.00,'canceled','2024-11-06 04:56:18','stripe',0,NULL,NULL,0),(73,10,77700.00,'canceled','2024-11-06 04:57:38','stripe',0,NULL,NULL,0),(74,10,77700.00,'canceled','2024-11-06 04:59:41','stripe',0,NULL,NULL,0),(75,10,77700.00,'canceled','2024-11-06 05:00:11','stripe',0,NULL,NULL,0),(76,10,77700.00,'canceled','2024-11-06 05:04:02','stripe',0,NULL,NULL,0),(77,10,77700.00,'canceled','2024-11-06 05:05:19','stripe',0,NULL,NULL,0),(78,10,77700.00,'canceled','2024-11-06 05:05:30','stripe',0,NULL,NULL,0),(79,10,77700.00,'completed','2024-11-06 05:06:12','stripe',0,NULL,NULL,0),(80,10,154800.00,'canceled','2024-11-06 05:11:25','stripe',0,NULL,NULL,0),(81,10,154800.00,'canceled','2024-11-06 05:11:54','stripe',0,NULL,NULL,0),(82,10,154800.00,'completed','2024-11-06 05:16:02','stripe',0,NULL,NULL,0),(83,10,0.00,'canceled','2024-11-06 05:17:07','stripe',0,NULL,NULL,0),(84,10,384600.00,'canceled','2024-11-06 05:17:39','stripe',0,NULL,NULL,0),(85,10,384600.00,'canceled','2024-11-06 05:19:29','stripe',0,NULL,NULL,0),(86,10,384600.00,'canceled','2024-11-06 05:20:12','stripe',0,NULL,NULL,0),(87,10,384600.00,'canceled','2024-11-06 05:20:41','stripe',0,NULL,NULL,0),(88,10,384600.00,'canceled','2024-11-06 05:20:47','stripe',0,NULL,NULL,0),(89,10,384600.00,'canceled','2024-11-06 05:20:55','stripe',0,NULL,NULL,0),(90,10,384600.00,'canceled','2024-11-06 05:21:21','stripe',0,NULL,NULL,0),(91,10,384600.00,'canceled','2024-11-06 05:32:53','stripe',0,NULL,NULL,0),(92,10,384600.00,'canceled','2024-11-06 05:33:21','stripe',0,NULL,NULL,0),(93,10,384600.00,'canceled','2024-11-06 06:19:30','paypal',0,NULL,NULL,0),(94,10,384600.00,'canceled','2024-11-06 06:19:51','stripe',0,NULL,NULL,0),(95,10,384600.00,'canceled','2024-11-06 06:20:23','stripe',0,NULL,NULL,0),(96,10,384600.00,'canceled','2024-11-06 06:20:55','stripe',0,NULL,NULL,0),(97,10,384600.00,'canceled','2024-11-06 06:43:11','stripe',0,NULL,NULL,0),(98,10,384600.00,'canceled','2024-11-06 06:44:28','stripe',0,NULL,NULL,0),(99,10,384600.00,'canceled','2024-11-06 06:44:38','stripe',0,NULL,NULL,0),(100,10,384600.00,'completed','2024-11-06 06:44:59','stripe',0,NULL,NULL,0),(101,10,151900.00,'canceled','2024-11-06 06:51:50','stripe',0,NULL,NULL,0),(102,10,151900.00,'canceled','2024-11-06 06:52:19','stripe',0,NULL,NULL,0),(103,10,151900.00,'canceled','2024-11-06 06:57:41','stripe',0,NULL,NULL,0),(104,10,151900.00,'canceled','2024-11-06 06:59:02','stripe',0,NULL,NULL,0),(105,10,151900.00,'canceled','2024-11-06 07:00:49','stripe',0,NULL,NULL,0),(106,10,151900.00,'canceled','2024-11-06 07:00:55','stripe',0,NULL,NULL,0),(107,10,151900.00,'completed','2024-11-06 07:08:39','paypal',0,NULL,NULL,0),(108,10,79300.00,'completed','2024-11-06 07:26:20','paypal',0,NULL,NULL,0),(109,10,76900.00,'completed','2024-11-06 07:40:02','paypal',0,NULL,NULL,0),(110,10,231800.00,'completed','2024-11-06 07:45:49','paypal',0,NULL,NULL,0),(111,10,378800.00,'canceled','2024-11-06 07:48:35','stripe',0,NULL,NULL,0),(112,10,378800.00,'completed','2024-11-06 07:50:20','paypal',0,NULL,NULL,0),(113,10,75000.00,'canceled','2024-11-06 07:54:16','stripe',0,NULL,NULL,0),(114,10,75000.00,'canceled','2024-11-06 07:54:45','stripe',0,NULL,NULL,0),(115,10,75000.00,'canceled','2024-11-06 07:55:46','stripe',0,NULL,NULL,0),(116,10,75000.00,'completed','2024-11-06 08:02:07','stripe',0,NULL,NULL,0),(117,10,235600.00,'completed','2024-11-06 09:20:24','stripe',0,NULL,NULL,0),(118,10,301800.00,'completed','2024-11-06 09:36:14','stripe',0,NULL,NULL,0),(119,10,75900.00,'canceled','2024-11-06 10:22:41','stripe',0,NULL,NULL,0),(120,10,75900.00,'canceled','2024-11-06 10:25:45','stripe',0,NULL,NULL,0),(121,10,75900.00,'canceled','2024-11-06 10:27:53','stripe',0,NULL,NULL,0),(122,10,75900.00,'canceled','2024-11-06 10:28:34','paypal',0,NULL,NULL,0),(123,10,75900.00,'canceled','2024-11-06 10:28:47','stripe',0,NULL,NULL,0),(124,10,75900.00,'canceled','2024-11-06 10:29:16','stripe',0,NULL,NULL,0),(125,10,75900.00,'canceled','2024-11-06 10:31:23','stripe',0,NULL,NULL,0),(126,10,75900.00,'canceled','2024-11-06 10:32:16','stripe',0,NULL,NULL,0),(127,10,75900.00,'canceled','2024-11-06 10:32:18','stripe',0,NULL,NULL,0),(128,10,75900.00,'canceled','2024-11-06 10:32:30','stripe',0,NULL,NULL,0),(129,10,75900.00,'canceled','2024-11-06 10:33:29','stripe',0,NULL,NULL,0),(130,10,75900.00,'completed','2024-11-06 10:33:58','stripe',0,NULL,NULL,0),(131,10,532700.00,'completed','2024-11-06 11:00:15','paypal',0,NULL,NULL,0),(132,10,376900.00,'completed','2024-11-06 11:01:45','stripe',0,NULL,NULL,0),(133,10,375000.00,'canceled','2024-11-06 11:04:53','stripe',0,NULL,NULL,0),(134,10,375000.00,'completed','2024-11-06 11:18:23','stripe',0,NULL,NULL,0),(135,10,85100.00,'completed','2024-11-07 04:32:02','stripe',0,NULL,NULL,0),(136,10,525900.00,'completed','2024-11-07 05:03:45','stripe',0,NULL,NULL,0),(137,10,80600.00,'completed','2024-11-07 05:18:06','stripe',0,NULL,NULL,0),(138,10,228400.00,'completed','2024-11-07 06:03:24','stripe',0,NULL,NULL,0),(139,10,398800.00,'completed','2024-11-07 11:48:10','stripe',0,NULL,NULL,0),(140,12,75000.00,'completed','2024-11-11 10:02:50','stripe',0,NULL,NULL,0),(141,10,303600.00,'canceled','2024-11-21 05:30:40','paypal',0,NULL,NULL,0),(142,10,303600.00,'canceled','2024-11-21 05:31:37','paypal',0,NULL,NULL,0),(143,10,303600.00,'canceled','2024-11-21 05:32:41','paypal',0,NULL,NULL,0),(144,10,303600.00,'canceled','2024-11-21 05:33:50','paypal',0,NULL,NULL,0),(145,10,303600.00,'canceled','2024-11-21 05:35:29','paypal',0,NULL,NULL,0),(146,10,303600.00,'canceled','2024-11-21 05:36:35','paypal',0,NULL,NULL,0),(147,10,303600.00,'canceled','2024-11-21 05:36:56','paypal',0,NULL,NULL,0),(148,10,303600.00,'canceled','2024-11-21 05:37:10','paypal',0,NULL,NULL,0),(149,10,303600.00,'canceled','2024-11-21 05:37:32','paypal',0,NULL,NULL,0),(150,10,303600.00,'canceled','2024-11-21 05:37:50','paypal',0,NULL,NULL,0),(151,10,303600.00,'canceled','2024-11-21 05:38:45','paypal',0,NULL,NULL,0),(152,10,303600.00,'canceled','2024-11-21 05:39:29','paypal',0,NULL,NULL,0),(153,10,303600.00,'canceled','2024-11-21 05:40:46','paypal',0,NULL,NULL,0),(154,10,303600.00,'canceled','2024-11-21 05:46:10','paypal',0,NULL,NULL,0),(155,10,303600.00,'canceled','2024-11-21 05:46:55','paypal',0,NULL,NULL,0),(156,10,303600.00,'canceled','2024-11-21 05:49:07','paypal',0,NULL,NULL,0),(157,10,303600.00,'canceled','2024-11-21 05:49:34','paypal',0,NULL,NULL,0),(158,10,75000.00,'completed','2024-11-21 09:48:20','stripe',0,NULL,NULL,0),(159,10,170000.00,'canceled','2024-11-22 08:11:30','paypal',0,NULL,NULL,0),(160,10,78300.00,'completed','2024-11-25 05:41:35','stripe',0,NULL,NULL,0),(161,10,299198.00,'canceled','2024-11-25 06:15:29','stripe',0,NULL,NULL,0),(162,10,299198.00,'canceled','2024-11-25 06:18:07','stripe',0,NULL,NULL,0),(163,10,299198.00,'completed','2024-11-25 06:29:41','stripe',0,NULL,NULL,0),(164,10,2400.00,'canceled','2024-11-25 06:47:25','paypal',0,NULL,NULL,0),(165,10,2400.00,'canceled','2024-11-25 06:47:40','stripe',0,NULL,NULL,0),(166,10,3400.00,'completed','2024-11-25 07:01:28','stripe',0,NULL,NULL,0),(167,10,153898.00,'canceled','2024-11-25 07:33:20','stripe',0,NULL,NULL,0),(168,10,153898.00,'canceled','2024-11-25 07:37:14','stripe',0,NULL,NULL,0),(169,10,153898.00,'canceled','2024-11-25 07:39:23','stripe',0,NULL,NULL,0),(170,10,153898.00,'canceled','2024-11-25 07:44:12','stripe',0,NULL,NULL,0),(171,10,153898.00,'canceled','2024-11-25 07:47:49','stripe',0,NULL,NULL,0),(172,10,153898.00,'canceled','2024-11-25 07:47:57','stripe',0,NULL,NULL,0),(173,10,153898.00,'canceled','2024-11-25 07:48:04','stripe',0,NULL,NULL,0),(174,10,153898.00,'canceled','2024-11-25 07:49:56','stripe',0,NULL,NULL,0),(175,10,153898.00,'canceled','2024-11-25 07:50:31','stripe',0,NULL,NULL,0),(176,10,153898.00,'canceled','2024-11-25 07:50:45','stripe',0,NULL,NULL,0),(177,10,153898.00,'canceled','2024-11-25 07:51:55','stripe',0,NULL,NULL,0),(178,10,153898.00,'canceled','2024-11-25 07:52:05','stripe',0,NULL,NULL,0),(179,10,153898.00,'canceled','2024-11-25 07:53:20','stripe',0,NULL,NULL,0),(180,10,153898.00,'canceled','2024-11-25 07:57:37','stripe',0,NULL,NULL,0),(181,10,153898.00,'canceled','2024-11-25 08:04:23','stripe',0,NULL,NULL,0),(182,10,153898.00,'canceled','2024-11-25 08:05:02','stripe',0,NULL,NULL,0),(183,10,153898.00,'canceled','2024-11-25 08:05:31','stripe',0,NULL,NULL,0),(184,10,153898.00,'canceled','2024-11-25 08:06:05','stripe',0,NULL,NULL,0),(185,10,153898.00,'canceled','2024-11-25 08:06:54','stripe',0,NULL,NULL,0),(186,10,153898.00,'completed','2024-11-25 08:08:13','stripe',0,NULL,NULL,0),(187,10,265999.00,'completed','2024-11-25 08:16:36','stripe',0,NULL,NULL,0),(188,10,150000.00,'completed','2024-11-25 09:39:47','stripe',0,NULL,NULL,0),(189,10,8900.00,'completed','2024-11-25 09:48:02','stripe',0,NULL,NULL,0),(190,10,75000.00,'completed','2024-11-25 09:58:49','stripe',0,NULL,NULL,0),(191,10,899.00,'completed','2024-11-25 10:03:08','stripe',0,NULL,NULL,0),(192,10,75899.00,'completed','2024-11-25 10:27:06','stripe',0,NULL,NULL,0),(193,10,2400.00,'completed','2024-11-25 10:34:29','stripe',0,NULL,NULL,0),(194,10,14400.00,'completed','2024-11-25 10:37:53','stripe',0,NULL,NULL,0),(195,10,75000.00,'completed','2024-11-25 10:40:11','stripe',0,NULL,NULL,0),(196,10,4397.00,'completed','2024-11-26 09:33:17','paypal',0,NULL,NULL,0),(197,9,77400.00,'completed','2024-11-26 09:37:49','paypal',0,NULL,NULL,0),(198,10,83739.00,'completed','2024-11-28 06:15:25','stripe',0,NULL,NULL,0),(199,12,456.00,'completed','2024-11-28 06:34:50','stripe',0,NULL,NULL,0),(200,12,540.00,'completed','2024-11-28 06:43:09','stripe',0,NULL,NULL,0),(201,12,231.00,'completed','2024-11-28 06:54:38','stripe',0,NULL,NULL,0),(202,2,1312.00,'completed','2024-11-28 07:23:07','stripe',0,NULL,NULL,0),(203,2,213.00,'completed','2024-11-28 07:48:05','stripe',0,NULL,NULL,0),(204,2,3211.00,'completed','2024-11-28 07:56:43','stripe',0,NULL,NULL,0),(205,10,123.00,'completed','2024-11-28 11:35:23','stripe',0,NULL,NULL,0),(206,10,246.00,'completed','2024-11-28 11:37:12','stripe',0,NULL,NULL,0),(207,10,615.00,'completed','2024-11-28 12:26:48','stripe',0,NULL,NULL,0),(208,10,3000.00,'completed','2024-11-29 08:15:31','stripe',0,NULL,NULL,0),(209,2,3000.00,'completed','2024-12-02 04:25:20','stripe',0,NULL,NULL,0),(210,2,3000.00,'canceled','2024-12-02 07:35:37','stripe',0,NULL,NULL,0),(211,2,3000.00,'completed','2024-12-02 07:46:23','stripe',0,NULL,NULL,0),(212,2,3000.00,'canceled','2024-12-02 07:48:02','stripe',0,NULL,NULL,0),(213,10,3000.00,'completed','2024-12-02 07:49:28','stripe',0,NULL,NULL,0),(214,10,3131.00,'completed','2024-12-02 12:26:45','stripe',0,NULL,NULL,0),(215,10,10345.00,'canceled','2024-12-03 05:26:32','',0,NULL,NULL,0),(216,10,10345.00,'canceled','2024-12-03 05:28:38','',0,NULL,NULL,0),(217,10,10345.00,'canceled','2024-12-03 05:34:52','',0,NULL,NULL,0),(218,10,10345.00,'canceled','2024-12-03 05:36:00','',0,NULL,NULL,0),(219,10,10345.00,'canceled','2024-12-03 05:36:02','',0,NULL,NULL,0),(220,10,10345.00,'canceled','2024-12-03 05:43:02','',0,NULL,NULL,0),(221,10,10345.00,'completed','2024-12-03 05:51:25','stripe',0,NULL,NULL,0),(222,10,3000.00,'completed','2024-12-03 11:24:47','stripe',0,NULL,NULL,0),(223,2,3000.00,'completed','2024-12-04 04:15:30','stripe',0,NULL,NULL,0),(224,2,3000.00,'completed','2024-12-04 04:39:32','stripe',0,NULL,NULL,0),(225,2,3000.00,'completed','2024-12-04 04:45:56','stripe',0,NULL,NULL,0),(226,2,3000.00,'completed','2024-12-04 05:03:31','stripe',0,NULL,NULL,0),(227,2,3000.00,'canceled','2024-12-04 05:18:16',NULL,0,NULL,NULL,0),(228,10,3000.00,'canceled','2024-12-04 05:29:49',NULL,0,NULL,NULL,0),(229,10,3000.00,'canceled','2024-12-04 05:37:20',NULL,0,NULL,NULL,0),(230,10,3000.00,'canceled','2024-12-04 05:38:59',NULL,0,NULL,NULL,0),(231,10,3000.00,'canceled','2024-12-04 05:40:43',NULL,0,NULL,NULL,0),(232,10,3000.00,'canceled','2024-12-04 05:41:15',NULL,0,NULL,NULL,0),(233,10,3000.00,'canceled','2024-12-04 05:41:52',NULL,0,NULL,NULL,0),(234,10,3000.00,'canceled','2024-12-04 05:51:24',NULL,0,NULL,NULL,0),(235,10,3000.00,'canceled','2024-12-04 06:00:22',NULL,0,NULL,NULL,0),(236,10,3000.00,'canceled','2024-12-04 06:06:03',NULL,0,NULL,NULL,0),(237,2,3000.00,'canceled','2024-12-04 06:06:26',NULL,0,NULL,NULL,0),(238,10,3000.00,'canceled','2024-12-04 06:11:41',NULL,0,NULL,NULL,0),(239,2,3000.00,'canceled','2024-12-04 06:11:51',NULL,0,NULL,NULL,0),(240,10,3000.00,'completed','2024-12-04 06:19:57','stripe',0,NULL,NULL,0),(241,2,3000.00,'canceled','2024-12-04 06:20:08',NULL,0,NULL,NULL,0),(242,10,3000.00,'canceled','2024-12-04 06:35:13',NULL,0,NULL,NULL,0),(243,10,3000.00,'canceled','2024-12-04 06:42:06',NULL,0,NULL,NULL,0),(244,10,3000.00,'canceled','2024-12-04 06:48:40',NULL,0,NULL,NULL,0),(245,10,3000.00,'canceled','2024-12-04 06:54:42',NULL,0,NULL,NULL,0),(246,10,3000.00,'canceled','2024-12-04 06:58:49',NULL,0,NULL,NULL,0),(247,10,3000.00,'canceled','2024-12-04 07:04:16',NULL,0,NULL,NULL,0),(248,10,3000.00,'canceled','2024-12-04 07:13:32',NULL,0,NULL,NULL,0),(249,10,3000.00,'canceled','2024-12-04 07:21:08',NULL,0,NULL,NULL,0),(250,10,3000.00,'canceled','2024-12-04 07:43:35',NULL,0,NULL,NULL,0),(251,10,3000.00,'canceled','2024-12-04 07:45:33',NULL,0,NULL,NULL,0),(252,10,3000.00,'canceled','2024-12-04 08:02:15',NULL,0,NULL,NULL,0),(253,10,3000.00,'canceled','2024-12-04 08:03:23',NULL,0,NULL,NULL,0),(254,10,3000.00,'canceled','2024-12-04 08:05:53',NULL,0,NULL,NULL,0),(255,2,2400.00,'canceled','2024-12-04 08:06:18',NULL,0,NULL,NULL,0),(256,10,3000.00,'canceled','2024-12-04 08:13:10',NULL,0,NULL,NULL,0),(257,10,3000.00,'canceled','2024-12-04 08:20:55',NULL,0,NULL,NULL,0),(258,10,3000.00,'canceled','2024-12-04 09:21:42',NULL,0,NULL,NULL,0),(259,10,3000.00,'canceled','2024-12-04 09:23:44',NULL,0,NULL,NULL,0),(260,2,1200.00,'canceled','2024-12-04 09:25:52',NULL,0,NULL,NULL,0),(261,10,3000.00,'canceled','2024-12-04 09:40:32',NULL,0,NULL,NULL,0),(262,10,3000.00,'canceled','2024-12-04 09:50:15',NULL,0,NULL,NULL,0),(263,10,3000.00,'canceled','2024-12-04 09:52:34',NULL,0,NULL,NULL,0),(264,10,3000.00,'canceled','2024-12-04 09:54:51',NULL,0,NULL,NULL,0),(265,10,3000.00,'canceled','2024-12-04 09:56:47',NULL,0,NULL,NULL,0),(266,10,3000.00,'canceled','2024-12-04 10:00:20',NULL,0,NULL,NULL,0),(267,10,3000.00,'canceled','2024-12-04 10:02:41',NULL,0,NULL,NULL,0),(268,10,3000.00,'canceled','2024-12-04 10:04:41',NULL,0,NULL,NULL,0),(269,10,3000.00,'canceled','2024-12-04 10:14:05',NULL,0,NULL,NULL,0),(270,10,3000.00,'canceled','2024-12-04 10:16:54',NULL,0,NULL,NULL,0),(271,10,3000.00,'canceled','2024-12-04 10:26:34',NULL,0,NULL,NULL,0),(272,10,3000.00,'canceled','2024-12-04 10:29:53',NULL,0,NULL,NULL,0),(273,10,3000.00,'canceled','2024-12-04 10:37:06',NULL,0,NULL,NULL,0),(274,10,3000.00,'completed','2024-12-04 10:45:30','stripe',0,NULL,NULL,0),(275,10,3000.00,'canceled','2024-12-04 10:46:40',NULL,0,NULL,NULL,0),(276,10,3000.00,'canceled','2024-12-04 10:53:28',NULL,0,NULL,NULL,0),(277,10,3000.00,'canceled','2024-12-04 10:57:39',NULL,0,NULL,NULL,0),(278,10,3000.00,'canceled','2024-12-04 11:02:55',NULL,0,NULL,NULL,0),(279,10,3000.00,'completed','2024-12-04 11:11:06','stripe',0,NULL,NULL,0),(280,10,600.00,'completed','2024-12-04 11:18:48','stripe',0,NULL,NULL,0),(281,10,600.00,'completed','2024-12-04 11:20:22','stripe',0,NULL,NULL,0),(282,10,600.00,'completed','2024-12-04 11:23:49','stripe',0,NULL,NULL,0),(283,10,600.00,'completed','2024-12-04 11:34:27','stripe',0,NULL,NULL,0),(284,10,600.00,'completed','2024-12-04 11:39:53','stripe',0,NULL,NULL,0),(285,10,3000.00,'canceled','2024-12-04 11:44:47',NULL,0,NULL,NULL,0),(286,10,1200.00,'canceled','2024-12-04 11:47:16',NULL,0,NULL,NULL,0),(287,10,1200.00,'canceled','2024-12-04 11:52:58',NULL,0,NULL,NULL,0),(293,10,600.00,'canceled','2024-12-04 12:03:50',NULL,0,NULL,NULL,0),(294,10,600.00,'canceled','2024-12-04 12:13:16',NULL,0,NULL,NULL,0),(295,10,600.00,'canceled','2024-12-04 12:20:58',NULL,0,NULL,NULL,0),(296,10,600.00,'canceled','2024-12-04 12:22:32',NULL,0,NULL,NULL,0),(297,2,600.00,'completed','2024-12-04 12:26:49','stripe',0,NULL,NULL,0),(298,2,600.00,'canceled','2024-12-04 12:27:40',NULL,0,NULL,NULL,0),(299,2,600.00,'completed','2024-12-04 12:30:15','stripe',0,NULL,NULL,0),(300,10,600.00,'canceled','2024-12-05 03:21:58',NULL,0,NULL,NULL,0),(301,10,600.00,'completed','2024-12-05 03:27:29','stripe',0,NULL,NULL,0),(302,10,600.00,'canceled','2024-12-05 04:05:01','stripe',0,NULL,NULL,1),(303,10,600.00,'completed','2024-12-05 04:07:42','stripe',0,NULL,NULL,0),(304,10,600.00,'canceled','2024-12-05 04:21:01','stripe',0,NULL,NULL,1),(305,10,600.00,'canceled','2024-12-05 04:33:14','stripe',0,NULL,NULL,0),(306,10,3000.00,'canceled','2024-12-05 04:36:43','stripe',0,NULL,NULL,0),(307,10,3000.00,'canceled','2024-12-05 05:58:01','stripe',0,NULL,NULL,1),(308,10,3000.00,'canceled','2024-12-05 06:01:01','stripe',0,NULL,NULL,1),(309,10,3000.00,'canceled','2024-12-05 06:02:55',NULL,0,NULL,NULL,0),(310,10,3000.00,'canceled','2024-12-05 06:06:26',NULL,0,NULL,NULL,0),(311,10,3000.00,'canceled','2024-12-05 06:17:01','stripe',0,NULL,NULL,1),(312,9,600.00,'pending','2024-12-05 06:16:11',NULL,0,NULL,NULL,0),(313,10,3000.00,'canceled','2024-12-05 06:41:01','stripe',0,NULL,NULL,1),(314,9,3000.00,'canceled','2024-12-05 06:39:26',NULL,0,NULL,NULL,0),(315,17,1200.00,'canceled','2024-12-05 06:43:48',NULL,0,NULL,NULL,0),(316,17,3000.00,'completed','2024-12-05 07:13:57','stripe',0,NULL,NULL,0),(317,10,2463.00,'pending','2024-12-05 07:34:33',NULL,0,NULL,NULL,0),(318,10,2463.00,'canceled','2024-12-05 07:35:29',NULL,0,NULL,NULL,0),(319,10,2463.00,'canceled','2024-12-05 07:39:31',NULL,0,NULL,NULL,0),(320,10,2463.00,'canceled','2024-12-05 07:49:37',NULL,0,NULL,NULL,0),(321,12,63.00,'canceled','2024-12-05 11:18:29',NULL,0,NULL,NULL,0),(322,17,153063.00,'canceled','2024-12-06 07:09:33',NULL,0,NULL,NULL,0),(323,17,153063.00,'canceled','2024-12-06 07:14:11',NULL,0,NULL,NULL,0),(324,10,5463.00,'canceled','2024-12-06 07:58:01','stripe',0,NULL,NULL,1),(325,17,153063.00,'canceled','2024-12-06 08:08:01','stripe',0,NULL,NULL,1),(326,17,153063.00,'canceled','2024-12-06 08:14:01','stripe',0,NULL,NULL,1),(327,10,5463.00,'canceled','2024-12-06 09:21:01','stripe',0,NULL,NULL,1),(328,10,5463.00,'canceled','2024-12-06 09:24:01','stripe',0,NULL,NULL,1),(329,10,5463.00,'canceled','2024-12-06 09:30:01','stripe',0,NULL,NULL,1),(330,10,5463.00,'canceled','2024-12-06 09:31:28',NULL,0,NULL,NULL,0),(331,10,5463.00,'completed','2024-12-06 09:35:35','stripe',0,NULL,NULL,0),(332,10,663.00,'completed','2024-12-06 10:00:32','stripe',0,NULL,NULL,0),(333,10,663.00,'completed','2024-12-06 10:02:28','stripe',0,NULL,NULL,0),(334,10,600.00,'canceled','2024-12-06 10:06:01','stripe',0,NULL,NULL,1),(335,10,1800.00,'canceled','2024-12-06 10:13:01','stripe',0,NULL,NULL,1),(336,10,1800.00,'canceled','2024-12-06 11:58:01','stripe',0,NULL,NULL,1),(337,9,1800.00,'completed','2024-12-06 12:00:07','stripe',0,NULL,NULL,0),(338,10,1800.00,'completed','2024-12-06 12:02:29','stripe',0,NULL,NULL,0),(339,10,63.00,'canceled','2024-12-09 04:58:09',NULL,0,NULL,NULL,0),(340,10,63.00,'canceled','2024-12-24 09:39:01',NULL,0,NULL,NULL,0),(341,12,63.00,'canceled','2024-12-26 08:37:50',NULL,0,NULL,NULL,0),(342,12,63.00,'completed','2024-12-26 09:25:52','stripe',0,NULL,NULL,0),(343,10,63.00,'completed','2025-01-02 07:01:10','stripe',0,NULL,NULL,0),(344,10,63.00,'canceled','2025-01-02 07:05:41',NULL,0,NULL,NULL,0),(345,10,63.00,'canceled','2025-01-02 07:07:49',NULL,0,NULL,NULL,0),(346,10,63.00,'canceled','2025-01-02 07:34:49',NULL,0,NULL,NULL,0),(347,10,63.00,'canceled','2025-01-02 07:38:02','stripe',0,NULL,NULL,1),(348,10,63.00,'canceled','2025-01-02 07:44:01','stripe',0,NULL,NULL,1),(349,10,63.00,'canceled','2025-01-02 07:53:01','stripe',0,NULL,NULL,1),(350,10,63.00,'canceled','2025-01-02 08:05:25',NULL,0,NULL,NULL,0),(351,10,63.00,'completed','2025-01-02 08:09:45','stripe',0,NULL,NULL,0),(352,10,63.00,'pending','2025-01-02 09:17:01','stripe',0,NULL,NULL,1),(353,10,63.00,'canceled','2025-01-02 09:17:52',NULL,0,NULL,NULL,0),(354,10,63.00,'pending','2025-01-02 09:23:59',NULL,0,NULL,NULL,0),(355,10,63.00,'pending','2025-01-02 09:26:02','stripe',0,NULL,NULL,1),(356,10,63.00,'pending','2025-01-02 09:26:02','paypal',0,NULL,NULL,1),(357,10,63.00,'pending','2025-01-02 09:26:22',NULL,0,NULL,NULL,0),(358,10,63.00,'canceled','2025-01-02 09:29:01','paypal',0,NULL,NULL,1),(359,10,63.00,'canceled','2025-01-02 09:50:01','paypal',0,NULL,NULL,1),(360,10,63.00,'pending','2025-01-02 09:55:02','paypal',0,NULL,NULL,1),(361,10,63.00,'canceled','2025-01-02 09:55:02','paypal',0,NULL,NULL,1),(362,10,63.00,'pending','2025-01-02 10:02:01','paypal',0,NULL,NULL,1),(363,10,63.00,'canceled','2025-01-02 10:02:01','stripe',0,NULL,NULL,1),(364,17,63.00,'canceled','2025-01-02 10:04:23','stripe',0,NULL,NULL,0),(365,17,75000.00,'pending','2025-01-02 10:08:01','stripe',0,NULL,NULL,1),(366,17,75000.00,'canceled','2025-01-02 10:06:26','stripe',0,NULL,NULL,0),(367,17,75000.00,'canceled','2025-01-02 10:12:37','stripe',0,NULL,NULL,0),(368,17,150000.00,'canceled','2025-01-02 10:13:10','stripe',0,NULL,NULL,0),(369,17,6500.00,'canceled','2025-01-02 10:16:11','stripe',0,NULL,NULL,0),(370,17,6500.00,'canceled','2025-01-02 10:19:02','stripe',0,NULL,NULL,0),(371,2,144900.00,'canceled','2025-01-02 10:22:01','stripe',0,NULL,NULL,1),(372,2,144900.00,'canceled','2025-01-02 10:26:30','stripe',0,NULL,NULL,0),(373,2,144900.00,'canceled','2025-01-02 10:26:49','stripe',0,NULL,NULL,0),(374,2,144963.00,'canceled','2025-01-02 10:50:42','stripe',0,NULL,NULL,0),(375,2,144963.00,'canceled','2025-01-02 11:06:01','stripe',0,NULL,NULL,1),(376,2,144963.00,'canceled','2025-01-02 11:07:24','stripe',0,NULL,NULL,0),(377,2,144963.00,'canceled','2025-01-02 11:07:49','stripe',0,NULL,NULL,0),(378,2,63.00,'canceled','2025-01-02 11:16:01','stripe',0,NULL,NULL,1),(379,2,63.00,'canceled','2025-01-02 11:26:03','stripe',0,NULL,NULL,0),(380,2,63.00,'canceled','2025-01-02 11:28:36','stripe',0,NULL,NULL,0),(381,2,63.00,'canceled','2025-01-02 11:32:54','stripe',0,NULL,NULL,0),(382,2,962.00,'canceled','2025-01-02 11:34:26','stripe',0,NULL,NULL,0),(383,2,899.00,'canceled','2025-01-02 11:34:56','stripe',0,NULL,NULL,0),(384,2,75000.00,'canceled','2025-01-02 11:38:19','stripe',0,NULL,NULL,0),(385,2,899.00,'canceled','2025-01-02 11:41:04','stripe',0,NULL,NULL,0),(386,2,899.00,'canceled','2025-01-02 11:44:05','stripe',0,NULL,NULL,0),(387,2,899.00,'pending','2025-01-02 11:52:01','stripe',0,NULL,NULL,1),(388,2,899.00,'canceled','2025-01-02 11:53:19','stripe',0,NULL,NULL,0),(389,2,899.00,'canceled','2025-01-02 12:20:46','stripe',0,NULL,NULL,0),(390,2,899.00,'canceled','2025-01-02 12:29:43','stripe',0,NULL,NULL,0),(391,2,899.00,'canceled','2025-01-03 03:51:36','stripe',0,NULL,NULL,0),(392,2,899.00,'canceled','2025-01-03 04:15:11',NULL,0,NULL,NULL,0),(393,2,899.00,'canceled','2025-01-03 04:42:46','stripe',0,NULL,NULL,0),(394,2,899.00,'canceled','2025-01-03 10:20:57','stripe',0,NULL,NULL,0),(395,2,899.00,'canceled','2025-01-03 10:21:46','stripe',0,NULL,NULL,0),(396,2,899.00,'canceled','2025-01-03 10:59:01','stripe',0,NULL,NULL,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `item_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `txn_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productName` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `originalPrice` varchar(100) NOT NULL,
  `sellingPrice` varchar(100) NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `categoryId` int NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `isWithheld` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categoryId` (`categoryId`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (15,'S24 Ultra 5G','SAMSUNG','200000','75000',123.00,6,99,0),(16,'chair','Damro','1000','900',2100.00,3,100,0),(17,'Table','Logitech_fur','2000','1000',2000.00,3,100,0),(18,'i phone 15','apple','100000','75000',200.00,6,100,0),(19,'FIFA 24','EA Sports','3999','2400',0.00,4,98,0),(20,'Acer Nitro 5','ACER','80000','75000',2000.00,5,100,0),(21,'Damro sofa','Damro','3000','2000',20000.00,3,100,0),(37,'I phone 16 pro max (256 gb)','Apple','144990','144900',190.00,6,100,0),(38,'Ford Mustang toy','Hotwheels','1000','899',200.00,4,99,0),(55,'poco m2 pro','poco','8000','6500',200.00,6,100,0),(57,'I phone 16','Apple','80000','75000',200.00,6,100,0),(64,'RTX 4090 24GB','Nvidia','100000','95000',123.00,3,100,0),(75,'Noise Buds N1 in-Ear True Ear Buds','noise','1900','1799',100.00,6,100,0),(85,'Bunny','Toy','799','599',200.00,4,100,0),(88,'PS5','Sony','50000','45000',1000.00,4,30,0),(93,'Fresh Apple Kashmir, 4 Pieces','Fresh','129','116',500.00,14,100,0),(95,'Prince of Persia Collection | PC Game | 𝐈𝐍𝐒𝐓𝐀𝐍𝐓 𝐄-𝐌𝐀𝐈𝐋 𝐃𝐄𝐋𝐈𝐕𝐄𝐑𝐘','UBISOFT','1999','999',0.00,4,100,0),(96,'Yamaha F280 Acoustic Rosewood Guitar (Natural, Beige)','YAMAHA','7990','7345',1000.00,3,6,0),(111,'Dumbbell','Fitness','1000','600',10000.00,15,2,0),(113,'Banana','Banana Man','100','63',231.00,15,98,0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Arka Pravo Dutta','dutta.arka@gmail.com','$2y$10$JIBgaxZ.7xDopMUtPXx/pOUGbg/67L6kFEFf.ctdgtYBf2SofGrxq','2024-10-29 03:52:07','admin'),(2,'Arka','dutta.arka123@gmail.com','$2y$10$YhgZu7QOQ3dPboP0zwUbGuIp3omejnhJbIIsZfmkzTYHKQh0.5Oq.','2024-10-29 05:03:29','customer'),(4,'shreya','shreya@gmail.com','$2y$10$UoKySc7yUetf97nfhofw..UiTnLejTmqEpav8jHVkEBH0udjuwjUm','2024-10-29 07:00:35','admin'),(9,'Arka_Yop','arka@yopmail.com','$2y$10$0ByGn1p0GcCi/7J4TrF..uZ4S/ie9K4OVumEW.7VyTmfynQEJasAG','2024-11-04 07:13:32','customer'),(10,'Arka Pravo Dutta','dutta.arkapravo11@gmail.com','$2y$10$rC8tcv9Wq6DLgDBeA13xXeaJ9.xCFAEF7X5Lo.OopqFa6DkQkD0hm','2024-11-05 04:49:40','customer'),(11,'Shreya Singh','shreya.singh@innofied.com','$2y$10$dE14o5NVSmkyB36O5M0gbey20pMFDRd11hb4oSIUGjFLgZzGQYiKS','2024-11-05 05:27:38','customer'),(12,'Prince Sharma','prince.sharma@innofied.com','$2y$10$MpV1Az4HKhljAEOkZnSY0.10j8X6FUaENAAoLMuEB/.9rinDoqdWi','2024-11-05 05:38:08','customer'),(14,'David Kramnick','davic@yopmal.com','$2y$10$FqnlzdwCfq.cz2rumq8XLuqmVHAKvR2gEpT6U2FmB5ZQIs80RrfW2','2024-11-26 03:57:14','customer'),(17,'arka@innofied','arkapravo.dutta@innofied.com','$2y$10$uLDZYju8m.wfkLnbLE/8qOf3ZrghXn7TM3XlKat4R1Bm4YLjYX9BK','2024-12-05 06:43:24','customer');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-08 10:03:28
